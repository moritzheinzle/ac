import kinem
import numpy as np
from numpy import pi, sin, cos, dot, sqrt, arctan2, arccos


class RobotArm(kinem.KinematicModel):
    def directGeometry(self, qi):
        l1, l2, l3 = self.l
        q1, q2, q3 = qi
        # TODO:

        # Homogenous transformation from 1 to 0
      
        # Homogenous transformation from 2 to 1

        # Homogenous transformation from 3 to 2
  
        # Homogenous transformation from 4 to 3
 
        # Homogenous transformation from 4 to 0
 

        # calculate joint positions from transformation matrices
        P1=P2=P3=P4=0
        return [P1, P2, P3, P4]

    
    def inverseGeometry(self, x, y, alpha = None):
        l1, l2, l3 = self.l
        # when no alpha, set it to the angle of the vector from origin to
        # target
        if alpha == None:
            alpha = arctan2(y, x)

        # TODO calculate new target(x, y) depending on alpha
        
        
        # TODO use inverse geometric approach 
        return ([0,0,0])
    

    def jacobian(self, qi):
        l1, l2, l3 = self.l
        q1, q2, q3 = qi

        #TODO calculate jacobian for 3 joints
        

        return np.array([
            [0, 0, 0],
            [0, 0, 0],
            [  0,   0,   0]
        ])