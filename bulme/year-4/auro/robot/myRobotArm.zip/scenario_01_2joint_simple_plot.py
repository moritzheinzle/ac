import kinem
from numpy import pi

#TODO:

# create RobotArm
robot = 

# define joint angles
q1 = 
q2 = 

# calculate joint positions (incl. end effector)
Pi = 
# draw robot with referential frame with axis length of 0.3
robot.plot(Pi, ref=0.3)